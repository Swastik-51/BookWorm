package com.bookworm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookWormApplicationTests {

	@Test
	void contextLoads() {
	}

}
