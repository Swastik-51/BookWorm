package com.bookworm.model;

public enum Role {
    USER,
    ADMIN
} 